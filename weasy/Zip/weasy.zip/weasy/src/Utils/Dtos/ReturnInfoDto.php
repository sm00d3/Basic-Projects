<?php

namespace Weasy\utils\Dtos;

class ReturnInfoDto
{
    public bool $HasError;
    public string $Message;
}