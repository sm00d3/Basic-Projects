<?php
    require_once "src/config.php";
    use Weasy\Utils\MiddleWare;
    $t = new MiddleWare($dbConnection);